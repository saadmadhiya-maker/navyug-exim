"""Offline smoke audit for this already-built vanilla HTML/JS site. Run: python tests/static_audit.py"""
from pathlib import Path
from html.parser import HTMLParser
import re,sys
ROOT=Path(__file__).resolve().parent.parent
class Inspect(HTMLParser):
    def __init__(self): super().__init__(); self.links=[];self.scripts=[];self.images=[];self.h1=0;self.canon=0;self.meta_desc=0
    def handle_starttag(self,t,attrs):
        d=dict(attrs)
        if t=='h1':self.h1+=1
        if t=='a' and d.get('href'):self.links.append(d['href'])
        if t=='script' and d.get('src'):self.scripts.append(d['src'])
        if t=='img' and d.get('src'):self.images.append(d['src'])
        if t=='link' and d.get('rel')=='canonical':self.canon+=1
        if t=='meta' and d.get('name')=='description':self.meta_desc+=1
errors=[];count=0
for path in sorted(ROOT.rglob('index.html')):
    text=path.read_text(encoding='utf8');count+=1
    doc=Inspect();doc.feed(text)
    route='/' if path.parent==ROOT else '/'+str(path.parent.relative_to(ROOT)).replace('\\','/')+'/'
    for condition,msg in [(doc.h1==1,'not one H1'),(doc.canon==1,'missing canonical'),(doc.meta_desc==1,'missing meta description'),('Dairy Roade' not in text,'old Roade spelling'),('site-footer' in text,'missing footer')]:
        if not condition:errors.append(f'{route}: {msg}')
    for url in doc.links+doc.scripts+doc.images:
        if not url.startswith('/') or url.startswith('//'):continue
        target=url.split('?',1)[0].split('#',1)[0]
        if target=='/':location=ROOT/'index.html'
        elif target.endswith('/'):location=ROOT/target.lstrip('/')/'index.html'
        else:location=ROOT/target.lstrip('/')
        if not location.exists():errors.append(f'{route}: missing local resource {target}')
for required in ['assets/original.css','assets/additions.css','assets/catalog.js','assets/home-original.js','assets/interactions.js','src/config/siteConfig.js','robots.txt','sitemap.xml']:
    if not (ROOT/required).exists():errors.append('missing '+required)
js=(ROOT/'assets/catalog.js').read_text(); products=re.findall(r"\{id:'([^']+)',name:'",js)
if len(products)!=16 or len(set(products))!=16:errors.append(f'Expected 16 unique original products, got {len(products)}')
for p in products:
 if not (ROOT/'products'/p/'index.html').exists(): errors.append('missing product route: '+p)
social=(ROOT/'src/config/siteConfig.js').read_text()
for n in ['youtube','facebook','instagram','linkedin']:
 if not re.search(r'"'+n+r'"\s*:\s*"https://[^"\s]+"',social):errors.append('missing configured HTTPS social profile '+n)
for deleted in ['categories','gallery']:
 if (ROOT/deleted).exists():errors.append('removed route still exists: '+deleted)
for required in ['blog/index.html','assets/revision.js','assets/translation.js','assets/revision.css','_worker.js','_redirects']:
 if not (ROOT/required).exists():errors.append('missing new file: '+required)
for slug in ['makhana','salt','wheat-flour','confectionery']:
 if not (ROOT/'assets/products'/(slug+'.webp')).exists():errors.append('missing user image '+slug)
print(f'PAGES={count} | ORIGINAL_PRODUCTS={len(products)} | ERRORS={len(errors)}')
for e in errors: print('FAIL:',e)
sys.exit(bool(errors))
