/** Product data copied from original Navyug Exim ZIP; update here to keep every page synchronized. */
const categories = [
  {name:'Onion', label:'Onions', icon:'🧅'},
  {name:'Fruits', label:'Fruits', icon:'🥭'},
  {name:'Vegetables', label:'Vegetables', icon:'🥬'},
  {name:'Spices', label:'Spices', icon:'🌶️'},
  {name:'Rice', label:'Rice', icon:'🌾'},
  {name:'Frozen Items', label:'Frozen', icon:'🧊'},
  {name:'Makhana / Fox Nuts', label:'Makhana', icon:'🌰'},
  {name:'Flour', label:'Flour', icon:'🥣'},
  {name:'Salt', label:'Salt', icon:'🧂'},
  {name:'Confectionery', label:'Sweets', icon:'🍬'}
];
const products = [
  {id:'red-onion',name:'Premium Red Onions',category:'Onion',icon:'🧅',desc:'Freshly sourced • Export grade',img:'https://images.unsplash.com/photo-1683355739329-cea18ba93f02?w=680&auto=format&fit=crop&q=80',info:'Indian red onions sourced for bulk international requirements. Ask us about sizes, grading, packing, availability and destination-specific terms.'},
  {id:'alphonso-mango',name:'Alphonso Mango',category:'Fruits',icon:'🥭',desc:'Rich flavour • Indian origin',img:'https://images.unsplash.com/photo-1553279768-865429fa0078?w=680&auto=format&fit=crop&q=80',info:'Premium Indian Alphonso mangoes for international buyers. Contact us for seasonality, packing options and volume requirements.'},
  {id:'pomegranate',name:'Fresh Pomegranate',category:'Fruits',icon:'🍎',desc:'Carefully selected • Fresh',img:'https://images.unsplash.com/photo-1615485925600-97237c4fc1ec?w=680&auto=format&fit=crop&q=80',info:'Indian pomegranates offered with attention to selection and packing. Grades and shipment availability are confirmed when you enquire.'},
  {id:'green-chilli',name:'Fresh Green Chilli',category:'Vegetables',icon:'🌶️',desc:'Hand-selected • Full of flavour',img:'https://images.unsplash.com/photo-1565685110871-1324fc462c84?w=680&auto=format&fit=crop&q=80',info:'Fresh green chillies from India for trade buyers. Send your preferred packing, quantity and delivery port for a quotation.'},
  {id:'tomato',name:'Farm-Fresh Tomatoes',category:'Vegetables',icon:'🍅',desc:'Vibrant • Freshly harvested',img:'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=680&auto=format&fit=crop&q=80',info:'Quality Indian tomatoes sourced for agricultural export. Tell us your preferred variety, grade and quantity.'},
  {id:'basmati',name:'Basmati Rice',category:'Rice',icon:'🍚',desc:'Aromatic • Carefully sourced',img:'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=680&auto=format&fit=crop&q=80',info:'Indian basmati rice available for international sourcing enquiries. Packaging, specifications and order quantities are discussed individually.'},
  {id:'turmeric',name:'Turmeric Powder',category:'Spices',icon:'🟡',desc:'Authentic Indian spice',img:'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=680&auto=format&fit=crop&q=80',info:'Authentic Indian turmeric powder and other spices for export. Ask for required packaging, specification and volume.'},
  {id:'banana',name:'Fresh Bananas',category:'Fruits',icon:'🍌',desc:'Tropical • Quality selected',img:'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=680&auto=format&fit=crop&q=80',info:'Indian bananas for export sourcing. Let us know your size preferences, packing and destination to discuss availability.'},
  {id:'okra',name:'Fresh Okra',category:'Vegetables',icon:'🥒',desc:'Green & fresh • Export enquiry',img:'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=680&auto=format&fit=crop&q=80',info:'Fresh okra / bhindi for international buyers, sourced to meet buyer-defined requirements.'},
  {id:'black-pepper',name:'Black Pepper',category:'Spices',icon:'⚫',desc:'Bold aroma • Indian spice',img:'https://images.unsplash.com/photo-1509358271058-acd22cc93898?w=680&auto=format&fit=crop&q=80',info:'Whole black pepper for international spice trade. Contact us to discuss quality, grades and packaging.'},
  {id:'makhana',name:'Makhana / Fox Nuts',category:'Makhana / Fox Nuts',icon:'🌰',desc:'Premium Indian snack crop',img:'/assets/products/makhana.webp',info:'Indian makhana / fox nuts for bulk export enquiries. Packaging and sorting can be discussed for your market.'},
  {id:'strawberries',name:'Frozen Strawberries',category:'Frozen Items',icon:'🍓',desc:'Frozen produce • Trade supply',img:'https://images.unsplash.com/photo-1464965911861-746a04b4bca6?w=680&auto=format&fit=crop&q=80',info:'Frozen strawberries are part of our frozen product range. Ask us about frozen storage, order requirements and shipment suitability.'},
  {id:'kesar-mango',name:'Kesar Mango',category:'Fruits',icon:'🥭',desc:'Sweet • Indian favourite',img:'https://images.unsplash.com/photo-1601493700631-2b16ec4b4716?w=680&auto=format&fit=crop&q=80',info:'Indian Kesar mangoes for seasonal export enquiries. We can discuss grading, packing and available quantities.'},
  {id:'wheat-flour',name:'Wheat Flour',category:'Flour',icon:'🥣',desc:'Staple food • Bulk sourcing',img:'/assets/products/wheat-flour.webp',info:'Indian flour for bulk export needs. Get in touch with your required specifications, grade and packing.'},
  {id:'salt',name:'Salt',category:'Salt',icon:'🧂',desc:'Essential commodity • Wholesale',img:'/assets/products/salt.webp',info:'Salt sourcing for international trade buyers. Contact us for product requirements and packaging details.'},
  {id:'confectionery',name:'Confectionery',category:'Confectionery',icon:'🍬',desc:'Candies & sweet treats',img:'/assets/products/confectionery.webp',info:'Indian confectionery products including candy, chocolate and lollipops, with options discussed according to supplier availability.'}
];
