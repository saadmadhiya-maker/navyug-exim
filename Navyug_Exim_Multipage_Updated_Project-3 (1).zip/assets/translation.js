/** Searchable 40-language switcher; genuine in-site text translation via /api/translate.
 * Needs secret GOOGLE_TRANSLATE_API_KEY in Cloudflare Pages; otherwise shows inline setup error.
 * Unlike the earlier version, never leaves the website for translate.google.com.
 */
(()=>{'use strict';
const languages=[
 ['en','English','English','🇬🇧'],['hi','Hindi','हिन्दी','🇮🇳'],['gu','Gujarati','ગુજરાતી','🇮🇳'],['ar','Arabic','العربية','🇸🇦'],
 ['fr','French','Français','🇫🇷'],['de','German','Deutsch','🇩🇪'],['es','Spanish','Español','🇪🇸'],['zh-CN','Chinese (Simplified)','简体中文','🇨🇳'],['zh-TW','Chinese (Traditional)','繁體中文','🇹🇼'],['ja','Japanese','日本語','🇯🇵'],['ko','Korean','한국어','🇰🇷'],['pt','Portuguese','Português','🇵🇹'],['ru','Russian','Русский','🇷🇺'],['it','Italian','Italiano','🇮🇹'],['tr','Turkish','Türkçe','🇹🇷'],['bn','Bengali','বাংলা','🇧🇩'],['ur','Urdu','اردو','🇵🇰'],['pa','Punjabi','ਪੰਜਾਬੀ','🇮🇳'],['ta','Tamil','தமிழ்','🇮🇳'],['te','Telugu','తెలుగు','🇮🇳'],['ml','Malayalam','മലയാളം','🇮🇳'],['mr','Marathi','मराठी','🇮🇳'],['kn','Kannada','ಕನ್ನಡ','🇮🇳'],['th','Thai','ไทย','🇹🇭'],['vi','Vietnamese','Tiếng Việt','🇻🇳'],['id','Indonesian','Bahasa Indonesia','🇮🇩'],['ms','Malay','Bahasa Melayu','🇲🇾'],['nl','Dutch','Nederlands','🇳🇱'],['pl','Polish','Polski','🇵🇱'],['sv','Swedish','Svenska','🇸🇪'],['sw','Swahili','Kiswahili','🇰🇪'],['fa','Persian','فارسی','🇮🇷'],['he','Hebrew','עברית','🇮🇱'],['el','Greek','Ελληνικά','🇬🇷'],['uk','Ukrainian','Українська','🇺🇦'],['ro','Romanian','Română','🇷🇴'],['cs','Czech','Čeština','🇨🇿'],['da','Danish','Dansk','🇩🇰'],['no','Norwegian','Norsk','🇳🇴'],['az','Azerbaijani','Azərbaycanca','🇦🇿']
];
const $=q=>document.querySelector(q);
const picker=$('#languagePicker');if(!picker)return;
const toggle=$('#languageToggle'),panel=$('#languagePanel'),search=$('#languageSearch'),list=$('#languageList'),current=$('#currentLanguage'),flag=$('#currentFlag'),status=$('#translationStatus');
const originalText=new Map(),originalAttrs=new Map();
const decodeHTML=s=>{const n=document.createElement('textarea');n.innerHTML=String(s);return n.value};
let selected='en',working=false,applying=false,generation=0,observer,offlineMode=false,offlineUntranslated=0;
const cachedLang=()=>{try{return localStorage.getItem('navyugLanguage')||'en'}catch(_){return 'en'}};
const saveLang=v=>{try{localStorage.setItem('navyugLanguage',v)}catch(_){}};
function setCurrent(code){selected=code;const found=languages.find(x=>x[0]===code)||languages[0];current.textContent=code==='en'?'EN':code.toUpperCase();flag.textContent=found[3];toggle.setAttribute('aria-label','Current language: '+found[1]);document.documentElement.lang=code;document.documentElement.dir=['ar','ur','fa','he'].includes(code)?'rtl':'ltr';}
function statusText(str,error=false){status.textContent=str;status.classList.toggle('error',error)}
function draw(q=''){
 const query=q.trim().toLocaleLowerCase();list.replaceChildren();
 const shown=languages.filter(([code,english,native])=>(english+' '+native+' '+code).toLocaleLowerCase().includes(query));
 if(!shown.length){const msg=document.createElement('p');msg.className='translation-note';msg.textContent='No matching languages';list.append(msg);return}
 shown.forEach(([code,english,native,emoji])=>{
  const btn=document.createElement('button');btn.type='button';btn.className='language-option';btn.setAttribute('role','option');btn.setAttribute('aria-selected',String(code===selected));btn.title=english;
  const emojiSpan=document.createElement('span');emojiSpan.className='lang-flag';emojiSpan.textContent=emoji;
  const nativeSpan=document.createElement('span');nativeSpan.className='lang-native';nativeSpan.textContent=native;
  const codeSpan=document.createElement('span');codeSpan.className='lang-code';codeSpan.textContent=code.toUpperCase();
  btn.append(emojiSpan,nativeSpan,codeSpan);btn.addEventListener('click',()=>{panel.hidden=true;toggle.setAttribute('aria-expanded','false');switchLanguage(code)});list.append(btn);
 });
}
function languageExempt(el){return !el||!!el.closest('script,style,svg,noscript,code,pre,textarea,#languagePicker,.notranslate,[translate="no"],.footer-contact a,.footer-contact p,.map-footer p,.map-card iframe');}
function textCandidates(root=document.body){
 const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);const entries=[];
 while(walker.nextNode()){
  const n=walker.currentNode;if(!n.textContent?.trim()||languageExempt(n.parentElement))continue;
  if(!originalText.has(n))originalText.set(n,n.nodeValue);
  if(!/[\p{L}]/u.test(originalText.get(n)))continue;
  entries.push({node:n,text:originalText.get(n)});
 }
 return entries;
}
function attributeCandidates(root=document.body){
 const res=[];const all=[root,...root.querySelectorAll('[placeholder],[aria-label],[title],[alt]')];
 all.forEach(el=>{if(el.nodeType!==1||languageExempt(el))return;
  for(const attr of ['placeholder','aria-label','title','alt']){
   if(!el.hasAttribute(attr))continue;
   if(!originalAttrs.has(el))originalAttrs.set(el,{});
   const obj=originalAttrs.get(el);if(!(attr in obj))obj[attr]=el.getAttribute(attr);
   if(/[\p{L}]/u.test(obj[attr]))res.push({node:el,attr,text:obj[attr]});
  }
 });return res;
}
function getEntries(root=document.body){return [...textCandidates(root),...attributeCandidates(root)]}
function setEntry(item,value){if(!item.node.isConnected)return;if(item.attr)item.node.setAttribute(item.attr,value);else item.node.nodeValue=value}
function restore(){applying=true;for(const [node,text] of originalText){if(node.isConnected)node.nodeValue=text}for(const [el,attrs] of originalAttrs){if(!el.isConnected)continue;Object.entries(attrs).forEach(([key,val])=>el.setAttribute(key,val))}applying=false}
function localBatch(arr,lang){
 const dictionary=window.NAVYUG_LOCAL_TRANSLATIONS?.[lang]||{};
 return arr.map(raw=>{const trimmed=raw.trim();const translated=dictionary[trimmed];if(!translated){offlineUntranslated++;return raw}const front=raw.match(/^\s*/)?.[0]||'';const back=raw.match(/\s*$/)?.[0]||'';return front+translated+back});
}
async function sendBatch(arr,lang){
 if(offlineMode)return localBatch(arr,lang);
 const resp=await fetch('/api/translate',{method:'POST',credentials:'same-origin',headers:{'content-type':'application/json'},body:JSON.stringify({target:lang,texts:arr})});
 const json=await resp.json().catch(()=>({}));if(!resp.ok){if(resp.status===503&&['hi','gu'].includes(lang)){offlineMode=true;return localBatch(arr,lang)}throw Error(json.error||'Translation is currently unavailable.');}
 if(!Array.isArray(json.translations)||json.translations.length!==arr.length)throw Error('Translation service returned an unexpected response.');
 return json.translations.map(decodeHTML);
}
async function translateEntries(entries,lang,run){
 const translation=[];let chunk=[],size=0;
 for(const ent of entries){if(!ent.node.isConnected)continue;if(size+ent.text.length>5800||chunk.length>=30){translation.push(chunk);chunk=[];size=0}chunk.push(ent);size+=ent.text.length}
 if(chunk.length)translation.push(chunk);
 for(const group of translation){
  if(run!==generation)return;
  const result=await sendBatch(group.map(e=>e.text),lang);
  if(run!==generation)return;
  applying=true;group.forEach((e,i)=>setEntry(e,result[i]));applying=false;
 }
}
async function switchLanguage(code,automatic=false){
 if(working)return;if(!languages.some(x=>x[0]===code))return;
 const previous=selected;generation++;const run=generation;
 if(code==='en'){restore();setCurrent('en');saveLang('en');statusText('English version active.');draw(search.value);return}
 offlineMode=false;offlineUntranslated=0;working=true;toggle.disabled=true;statusText('Translating page…');
 try{
  restore();const entries=getEntries();await translateEntries(entries,code,run);
  if(run!==generation)return;
  setCurrent(code);saveLang(code);draw(search.value);statusText(offlineMode?'Basic '+(languages.find(x=>x[0]===code)?.[1]||code)+' translation applied. Some content remains in English until the full translation service is configured.':'Translated into '+(languages.find(x=>x[0]===code)?.[1]||code)+'.');
 }catch(error){restore();setCurrent('en');saveLang('en');statusText(error.message||'Translation failed. Please try again.',true);draw(search.value)}
 finally{working=false;toggle.disabled=false}
}
// Preserve selected language across page changes without altering URLs or redirecting to Google Translate.
setCurrent('en');draw();
toggle.addEventListener('click',()=>{const opened=panel.hidden;panel.hidden=!opened;toggle.setAttribute('aria-expanded',String(opened));if(opened){search.value='';draw();search.focus()}});
search.addEventListener('input',()=>draw(search.value));
search.addEventListener('keydown',e=>{if(e.key==='ArrowDown'){e.preventDefault();list.querySelector('button')?.focus()}});
list.addEventListener('keydown',e=>{if(!['ArrowDown','ArrowUp'].includes(e.key))return;e.preventDefault();const options=[...list.querySelectorAll('button')],i=options.indexOf(document.activeElement);options[Math.min(options.length-1,Math.max(0,i+(e.key==='ArrowDown'?1:-1)))]?.focus()});
document.addEventListener('pointerdown',e=>{if(!picker.contains(e.target)){panel.hidden=true;toggle.setAttribute('aria-expanded','false')}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!panel.hidden){panel.hidden=true;toggle.setAttribute('aria-expanded','false');toggle.focus()}});
// Dynamic product cards, filter labels and product modals are translated too, if service configured.
let queued=[];let mutationTimer;
observer=new MutationObserver(records=>{
 if(applying||selected==='en'||working)return;
 const fresh=records.some(record=>record.type==='childList'&&record.addedNodes.length);
 if(!fresh)return;
 clearTimeout(mutationTimer);
 mutationTimer=setTimeout(async()=>{if(working||selected==='en')return;
   try{const entries=getEntries().filter(e=>e.attr?e.node.getAttribute(e.attr)===e.text:e.node.nodeValue===e.text);if(entries.length)await translateEntries(entries,selected,generation)}catch(_){statusText('New content could not be translated. Try selecting the language again.',true)}
 },220);
});
observer.observe(document.body,{subtree:true,childList:true});
const preference=cachedLang();if(preference!=='en'&&languages.some(x=>x[0]===preference)){setTimeout(()=>switchLanguage(preference,true),90)}
})();
