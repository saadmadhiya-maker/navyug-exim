/** Batch-1 functionality: consistent product detail dialog for Products page. */
(()=>{'use strict';
  const byId=id=>document.getElementById(id);
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const modal=byId('productModal');
  if(document.body.dataset.page==='/products/'&&modal){
    let previousFocus;
    window.navyugOpenProduct=id=>{
      const item=(typeof products!=='undefined'?products:[]).find(p=>p.id===id);
      if(!item)return;
      previousFocus=document.activeElement;
      byId('modalCategory').textContent=item.category.toUpperCase();
      byId('modalTitle').textContent=item.name;
      byId('modalDesc').textContent=item.info;
      byId('modalImage').innerHTML=item.img?`<span class="modal-fallback">${item.icon}</span><img src="${esc(item.img)}" alt="${esc(item.name)}" onerror="this.remove()"/>`:`<span class="modal-fallback">${item.icon}</span>`;
      byId('modalQuote').dataset.id=item.id;
      modal.hidden=false;document.body.classList.add('modal-open');byId('modalClose')?.focus();
    };
    const close=()=>{modal.hidden=true;document.body.classList.remove('modal-open');previousFocus?.focus?.()};
    byId('modalClose')?.addEventListener('click',close);
    modal.addEventListener('click',e=>{if(e.target===modal)close()});
    document.addEventListener('keydown',e=>{
      if(modal.hidden)return;
      if(e.key==='Escape')close();
      if(e.key==='Tab'){const list=Array.from(modal.querySelectorAll('button:not([disabled]),a[href]'));if(!list.length)return;const first=list[0],last=list[list.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}
    });
    byId('modalQuote')?.addEventListener('click',()=>{
      const slug=byId('modalQuote').dataset.id;close();
      window.location.assign(`/contact/?product=${encodeURIComponent(slug)}#enquiry`);
    });
  }
  // Product detail deep links kept for search engines and copyable URLs.
})();
