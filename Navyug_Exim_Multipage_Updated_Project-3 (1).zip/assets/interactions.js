/** NAVYUG EXIM — additions for multi-page navigation, social settings, language, gallery and forms. */
(() => {
  'use strict';
  const $ = (q,root=document)=>root.querySelector(q);
  const $$ = (q,root=document)=>Array.from(root.querySelectorAll(q));
  const esc = t=>String(t??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const items = typeof products==='undefined'?[]:products;
  const groups = typeof categories==='undefined'?[]:categories;
  const isHome = document.body.dataset.page==='/' ;
  const wa = '918799548724';

  // The original ZIP's logo, palette, product design and homepage scripts are retained.
  // Other pages share the same product data and styling.
  if (!isHome) {
    const trigger=$('#menuBtn'), menu=$('#mobileMenu');
    trigger?.addEventListener('click',()=>{const open=!menu.classList.contains('open');menu.classList.toggle('open',open);trigger.setAttribute('aria-expanded',String(open));});
    $$('#mobileMenu a').forEach(a=>a.addEventListener('click',()=>{menu?.classList.remove('open');trigger?.setAttribute('aria-expanded','false');}));
  }

  // Link configs live in one file; do not display placeholder profiles as active links.
  const socials=window.NAVYUG_SITE_CONFIG?.socialLinks||{};
  const socialNames={youtube:'YouTube',facebook:'Facebook',instagram:'Instagram',linkedin:'LinkedIn'};
  // Consistent lightweight line icons: no solid/heavy silhouette fills.
  const socialIcons={
    youtube:'<rect x="2" y="5" width="20" height="14" rx="4"/><path d="m10 9 5 3-5 3z"/>',
    facebook:'<path d="M17 3h-3a4 4 0 0 0-4 4v3H7v4h3v7h4v-7h3l.7-4H14V7a1 1 0 0 1 1-1h2"/>',
    instagram:'<rect x="2.5" y="2.5" width="19" height="19" rx="5"/><circle cx="12" cy="12" r="4"/><path d="M17.8 6.3h.01"/>',
    linkedin:'<rect x="2.5" y="2.5" width="19" height="19" rx="3"/><path d="M7.3 10v7.5m0-11v.1M11 17.5V10h0v1.5a3.2 3.2 0 0 1 6.3 0v6"/>'
  };
  $$('#socialList').forEach(box=>{
    Object.entries(socialNames).forEach(([key,label])=>{
      const url=String(socials[key]||'').trim();
      if(!/^https:\/\/[^\s]+$/i.test(url))return;
      const a=document.createElement('a');a.className='social-link';a.href=url;a.target='_blank';a.rel='noopener noreferrer';a.setAttribute('aria-label',`NAVYUG EXIM on ${label}`);a.title=label;
      a.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${socialIcons[key]}</svg>`;box.append(a);
    });
  });

  // Site-wide searchable language picker is initialized by translation.js.

  // Shared data-driven cards for separate Products and Categories pages.
  if (!isHome && $('#productsGrid')) {
    const grid=$('#productsGrid'),categoryList=$('#categoryList'),search=$('#productSearch'),clear=$('#searchClear'),more=$('#showMore');
    let filter=new URLSearchParams(window.location.search).get('category')||'All';
    if(filter!=='All'&&!groups.some(g=>g.name===filter))filter='All';
    let favs=new Set();try{favs=new Set(JSON.parse(localStorage.getItem('navyugFavorites')||'[]'))}catch(_){}
    const photo=p=>p.img?`<img src="${esc(p.img)}" alt="Illustrative photo of ${esc(p.name)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.hidden=false"><span class="product-emoji" hidden>${p.icon}</span>`:`<span class="product-emoji">${p.icon}</span>`;
    function render(){
      const query=String(search?.value||'').trim().toLocaleLowerCase();
      const list=items.filter(p=>(filter==='All'||(filter==='Favorites'?favs.has(p.id):p.category===filter))&&(`${p.name} ${p.category} ${p.desc}`.toLowerCase().includes(query)));
      grid.innerHTML=list.map(p=>`<article class="product-card" data-id="${esc(p.id)}"><div class="product-photo${p.img?'':' no-image'}" role="button" tabindex="0" data-detail="${esc(p.id)}" aria-label="Open details about ${esc(p.name)}">${photo(p)}<button type="button" class="save-btn ${favs.has(p.id)?'saved':''}" data-save="${esc(p.id)}" aria-label="${favs.has(p.id)?'Remove saved':'Save'} ${esc(p.name)}" aria-pressed="${favs.has(p.id)}"><svg><use href="#i-heart"></use></svg></button></div><div class="product-body"><div class="product-tag">${esc(p.category)}</div><h3 class="product-title"><a href="/products/${encodeURIComponent(p.id)}/">${esc(p.name)}</a></h3><p class="product-desc">${esc(p.desc)}</p><div class="product-bottom"><span class="product-note">Quote on request</span><a class="product-plus" href="/contact/?product=${encodeURIComponent(p.id)}#enquiry" aria-label="Request quote for ${esc(p.name)}">+</a></div></div></article>`).join('');
      if($('#emptyState'))$('#emptyState').hidden=!!list.length;
      if(more)more.hidden=true;
      $$('.filter').forEach(b=>{const match=b.dataset.filter===filter;b.classList.toggle('active',match);b.setAttribute('aria-pressed',String(match))});
      if(categoryList)categoryList.innerHTML=groups.map(c=>`<button class="category-pill ${filter===c.name?'selected':''}" type="button" data-cat="${esc(c.name)}"><span class="category-visual">${c.icon}</span><span>${esc(c.label)}</span></button>`).join('');
    }
    render();
    categoryList?.addEventListener('click',e=>{const b=e.target.closest('[data-cat]');if(!b)return;filter=b.dataset.cat;render();$('#products')?.scrollIntoView({behavior:'smooth'})});
    $$('.filter').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.filter;render()}));
    search?.addEventListener('input',()=>{if(clear)clear.hidden=!search.value;render()});
    clear?.addEventListener('click',()=>{search.value='';clear.hidden=true;render();search.focus()});
    $('#resetFilters')?.addEventListener('click',()=>{filter='All';if(search)search.value='';render()});
    grid.addEventListener('click',e=>{const productTitle=e.target.closest('.product-title a');if(productTitle){e.preventDefault();window.navyugOpenProduct?.(productTitle.closest('[data-id]')?.dataset.id);return;}const btn=e.target.closest('[data-save]');if(btn){const id=btn.dataset.save;favs.has(id)?favs.delete(id):favs.add(id);try{localStorage.setItem('navyugFavorites',JSON.stringify([...favs]))}catch(_){}render();return;}const detail=e.target.closest('[data-detail],.product-card');if(detail)window.navyugOpenProduct?.(detail.dataset.detail||detail.dataset.id)});
    grid.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-detail]')){e.preventDefault();window.navyugOpenProduct?.(e.target.dataset.detail)}});

  }

  // Product photo gallery uses the same original data, with search, filters and an accessible modal.
  const galleryGrid=$('#galleryGrid'),galleryFilters=$('#galleryFilters'),gallerySearch=$('#gallerySearch');
  if(galleryGrid){
    let filter='All';
    function drawGallery(){
      const q=String(gallerySearch.value||'').trim().toLowerCase();
      const list=items.filter(p=>(filter==='All'||p.category===filter)&&`${p.name} ${p.category} ${p.desc}`.toLowerCase().includes(q));
      galleryFilters.innerHTML=[['All','All products','🌿'],...groups.map(c=>[c.name,c.label,c.icon])].map(([id,label,icon])=>`<button type="button" class="filter ${filter===id?'active':''}" data-filter="${esc(id)}" aria-pressed="${filter===id}">${icon} ${esc(label)}</button>`).join('');
      galleryGrid.innerHTML=list.map(p=>`<article class="gallery-tile"><button type="button" class="gallery-photo ${p.img?'':'fallback-photo'}" data-photo="${esc(p.id)}" aria-label="Enlarge photo of ${esc(p.name)}">${p.img?`<img loading="lazy" src="${esc(p.img)}" alt="Illustrative photo: ${esc(p.name)}" onerror="this.style.display='none';this.nextElementSibling.hidden=false"><span class="photo-emoji" hidden>${p.icon}</span>`:`<span class="photo-emoji">${p.icon}</span>`}</button><div class="gallery-tile-copy"><span class="overline">${esc(p.category)}</span><h3>${esc(p.name)}</h3><p>${esc(p.desc)}</p><a href="/products/${encodeURIComponent(p.id)}/">Product details →</a></div></article>`).join('');
      $('#galleryEmpty').hidden=!!list.length;
    }
    drawGallery();
    galleryFilters.addEventListener('click',e=>{const b=e.target.closest('[data-filter]');if(!b)return;filter=b.dataset.filter;drawGallery()});
    gallerySearch.addEventListener('input',()=>{$('#galleryClear').hidden=!gallerySearch.value;drawGallery()});
    $('#galleryClear')?.addEventListener('click',()=>{gallerySearch.value='';$('#galleryClear').hidden=true;drawGallery();gallerySearch.focus()});
    let modal;
    galleryGrid.addEventListener('click',e=>{
      const b=e.target.closest('[data-photo]');if(!b)return;const p=items.find(i=>i.id===b.dataset.photo);if(!p)return;
      if(!modal){modal=document.createElement('div');modal.className='gallery-lightbox';modal.hidden=true;modal.innerHTML='<div class="lightbox-dialog" role="dialog" aria-modal="true" aria-label="Product photo preview"><button class="lightbox-close" aria-label="Close photo preview">✕</button><div class="lightbox-content"></div></div>';document.body.append(modal)}
      $('.lightbox-content',modal).innerHTML=p.img?`<img src="${esc(p.img)}" alt="Illustrative product photograph of ${esc(p.name)}"><p>${esc(p.name)} — illustrative stock photo, not verified as a company product image.</p>`:`<div class="fallback-photo" style="min-height:220px"><span class="photo-emoji">${p.icon}</span><p>${esc(p.name)} — original photograph not supplied.</p></div>`;
      modal.hidden=false;document.body.style.overflow='hidden';$('.lightbox-close',modal).focus();
    });
    document.addEventListener('click',e=>{if(modal&&(e.target===modal||e.target.closest('.lightbox-close'))){modal.hidden=true;document.body.style.overflow=''}});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal&&!modal.hidden){modal.hidden=true;document.body.style.overflow=''}});
  }

  // Original WhatsApp quote form is retained on Home; initialize only on Contact.
  if(!isHome){
    const form=$('#quoteForm'), select=$('#quoteProduct');
    if(form&&select){
      select.innerHTML='<option value="">Select a product</option>'+items.map(p=>`<option value="${esc(p.name)}" data-id="${esc(p.id)}">${esc(p.name)}</option>`).join('');
      const wanted=new URLSearchParams(window.location.search).get('product');
      const item=items.find(p=>p.id===wanted);if(item)select.value=item.name;
      form.addEventListener('submit',event=>{
        event.preventDefault();if(!form.reportValidity())return;
        const d=new FormData(form),val=k=>String(d.get(k)||'').trim();
        const message=[`Hello NAVYUG EXIM, I would like to request an export quotation.`, `Name: ${val('name')}`,val('company')?`Company: ${val('company')}`:'',`Email: ${val('email')}`,`Destination: ${val('country')}`,`Product: ${val('product')}`,val('quantity')?`Quantity: ${val('quantity')}`:'',val('message')?`Requirements: ${val('message')}`:'', 'Please share availability and an export quotation.'].filter(Boolean).join('\n');
        const url=`https://wa.me/${wa}?text=${encodeURIComponent(message)}`;
        const popup=window.open(url,'_blank','noopener,noreferrer');if(!popup)window.location.assign(url);
      });
    }
  }
})();
