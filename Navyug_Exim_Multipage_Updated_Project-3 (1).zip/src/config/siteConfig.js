/** NAVYUG EXIM social profiles — official links supplied by project owner. */
window.NAVYUG_SITE_CONFIG = {
  "socialLinks": {
    "youtube": "https://www.youtube.com/@NavyugExim",
    "facebook": "https://www.facebook.com/people/Navyug-Exim/pfbid021ZJcFEu4yLqQMwuZKTi7VRXe9TypsqRG1Hc6P6bdfBU1w4LYGEazzg4kxDpAG2L3l/?rdid=WRD4fcdJucDnTuZ5&share_url=https%3A%2F%2Fwww.facebook.com%2Fshare%2F18iZ28fQRq%2F",
    "instagram": "https://www.instagram.com/navyugexim26?igsh=ZXdyc2ZuMXc5YTl3&utm_source=ig_contact_invite",
    "linkedin": "https://www.linkedin.com/in/navyug-exim-287a54403/"
  },
  "creatorLink": "https://www.linkedin.com/in/saad-madhiya-155521439/"
};
