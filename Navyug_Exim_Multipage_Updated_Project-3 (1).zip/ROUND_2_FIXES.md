# NAVYUG EXIM — Screenshot-reported UI fixes (13 October 2026)

This update modifies the existing 22-page vanilla HTML/CSS/JS site. It does not redesign the homepage.

## Changed
- All product popup images now use `object-fit: contain` in a white padded image area so full product images, including tall tomato photos and wide rice photos, remain visible.
- FAQ question's `NAVYUG EXIM` brand span no longer inherits the accordion plus-icon transform or layout. Text can wrap normally.
- Search and quote form focus styles override the old orange/gold border/outline; keyboard focus on actionable controls remains subtly visible in green.
- Social/footer icons changed to lightweight stroke-only vector icons; floating WhatsApp gets a thinner outlined symbol.
- The language toggle uses the provided translator-icon image, kept in the website's green/cream UI, with a searchable language menu.
- Added *basic offline* Hindi and Gujarati translation dictionaries for common navigation, product names, and labels. This is an intentionally partial fallback, not complete site-wide translation.

## Translation limitations / production setup
- For complete translation to any supported language, configure the Cloudflare Pages production secret `GOOGLE_TRANSLATE_API_KEY` for Google Cloud Translation API, and redeploy.
- Without a key, common Hindi/Gujarati labels can fall back to a small built-in offline dictionary. Some content will stay in English and the UI discloses this.
- Other languages still require the API key, and are not functional without one. We do not claim otherwise.
- English brand name and supplied logo are explicitly excluded from translation. The user-supplied Google Translate logo is only a visual icon; this implementation uses its own secure Cloudflare backend for the optional API.

## Deploy
Replace the repository ZIP at `Navyug_Exim_Multipage_Updated_Project-3.zip` on GitHub `main`. Existing Cloudflare Pages setting can remain: 

- Build command: `python3 -m zipfile -e Navyug_Exim_Multipage_Updated_Project-3.zip dist`
- Build output directory: `dist`
- Framework preset: `None`

Check the new deployment for success and manually test photo fit, FAQs, search/form focus, language selector and mobile layout.
