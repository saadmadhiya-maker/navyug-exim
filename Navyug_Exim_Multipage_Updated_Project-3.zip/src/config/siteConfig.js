/** Edit these FOUR values with official NAVYUG EXIM profile URLs. Empty links are hidden. */
window.NAVYUG_SITE_CONFIG = {
  socialLinks: {
    youtube: '',
    facebook: '',
    instagram: '',
    linkedin: ''
  }
};
