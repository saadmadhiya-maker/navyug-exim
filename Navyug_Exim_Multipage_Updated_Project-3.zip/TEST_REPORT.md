# QA / TESTING REPORT — Navyug Exim multi-page update

## Passing offline checks (12 October 2026)

- ZIP source inspected: original **one-file vanilla HTML/CSS/JavaScript** project, no npm package dependencies or build tool.
- Original `style` stylesheet moved unchanged into `assets/original.css`; product data extracted from original source, product details preserved. Original homepage sections and homepage script retained.
- Original address text `Roade` corrected to `Road` across all generated pages.
- Offline static audit: **23 HTML page routes**, one H1, canonical link, description meta tag and footer on every page; **0 broken local resource references**.
- All **16 original catalogue products** each have a unique product-detail directory and SEO metadata.
- Category catalogue: all 10 categories retained from original ZIP.
- All 4 social profile values are empty and social links are hidden by default.
- JavaScript parsing: `node --check` passed on `assets/catalog.js`, `assets/home-original.js`, `assets/interactions.js`.
- CSS parsing: 0 top-level parse errors in original and additions stylesheet (`tinycss2`).
- Served locally with Python HTTP server: **HTTP 200** on `/`, `/about/`, `/products/`, `/products/red-onion/`, `/categories/`, `/gallery/`, `/certificates/` and `/contact/`.
- `sitemap.xml`, `robots.txt`, CSS, JS and logo paths exist and are correctly rooted for Cloudflare Pages.

## Implemented but NOT independently browser-tested

The container browser automation returned `net::ERR_BLOCKED_BY_ADMINISTRATOR` for both loopback and file URLs. Thus the following could not be certified as having passed interaction tests, although their source-code logic is included and static-checked:

- Visual pixel match to live Cloudflare site (the live reference could not be fetched).
- Actual mobile and desktop rendering, overflow, gallery lightbox opening and keyboard focus behavior.
- Live product-card filtering and search, saved favourites persistence, FAQ disclosure, navigation / dropdown interactions.
- WhatsApp hand-off in a real mobile browser.
- Google Maps iframe loading (Google may block embeds depending on security policies).
- External product photograph load success (images are hosted on Unsplash).
- Live Cloudflare pages deep-link behavior after production deployment.
- External Google Translate website translation result, page navigation while translating, or language persistence within the external translation service.

**These checks must be completed after deployment on Chrome (Android and desktop) before sharing a final public link.**

## Features blocked by missing documents or service

- Actual owner photographs, names and designations, exact company history: original developer website was inaccessible and photos/details absent from the ZIP. About page uses a clearly marked awaiting-content placeholder.
- Actual certificate images or verified details: absent. Certificates page explicitly says "Verified certificates pending" without fabricated certification claims.
- Original product photography: currently external illustrative stock links and emoji fallbacks. Replace with company-approved product assets.
- **Native in-site translation is not implemented**: searchable selector links to Google's external website-translation service for the current page. Availability varies by region, and Google retired support for its old embedded translation widget starting October 1, 2026. For fully integrated site-wide translation, a maintained translation provider or Google Cloud Translation API with a **server-side** integration and billing must be configured. No API credentials are included.
- No GitHub push or Cloudflare production deploy was performed. These require account access and deployment verification.
