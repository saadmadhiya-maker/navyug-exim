# Verified Company Material Still Needed

1. **Owner / director portrait(s):** real photos in JPG/PNG/WebP and written permission to publish; exact names and designations, approved biographies.
2. **About Us authentic text:** company profile, verifiable history, mission, vision and any claims the owner approves for public use.
3. **Certificates:** real PDF/PNG/JPG copies; exact certificate title, issuing authority, scope and expiration date if applicable. Do not publish a certification claim without evidence.
4. **Product images:** authentic company product photos for original 16 items and information on which photo matches which product. Current site uses external illustrative Unsplash photos and emoji placeholders.
5. **Additional products or categories:** if the developer website includes more than the 16 products/10 categories in the ZIP, provide a reliable catalogue or screenshots/images because that site could not be fetched here.
6. **Social media URLs:** edit four blank settings in `src/config/siteConfig.js` (`youtube`, `facebook`, `instagram`, `linkedin`).
7. **Address:** old ZIP states `Shop-02, Near Bus Stop, Dairy Road, Junisendhani, Vadgam, Banas Kantha, Gujarat – 385421, India.` Only `Roade` → `Road` was changed. The supplied Google Maps pin is Juni Sendhani village, not a verified storefront point.
8. **Automatic integrated translation (optional):** choose a translation provider and, if required, configure a server-side API account (API key, budget, rate limits, privacy notice). No private credentials should be committed to GitHub.
