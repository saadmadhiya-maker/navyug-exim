/***** Original homepage behaviour, retained from uploaded ZIP; catalog loaded separately. *****/

/** Navyug Exim — premium agricultural export demo. No server or checkout required. */
const WHATSAPP_NUMBER = '918799548724';
const $ = (s, root=document)=>root.querySelector(s);
const $$ = (s, root=document)=>[...root.querySelectorAll(s)];
const grid=$('#productsGrid');
const categoryList=$('#categoryList');
const productSearch=$('#productSearch');
const clearSearch=$('#searchClear');
const showMore=$('#showMore');
let activeFilter='All';
let expanded=false;
let favorites=new Set();
try{ favorites=new Set(JSON.parse(localStorage.getItem('navyugFavorites')||'[]')) }catch(_){/* private mode */}
const escapeHTML=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const imageMarkup=(item,cls='')=>item.img?`<img class="${cls}" src="${escapeHTML(item.img)}" loading="lazy" alt="${escapeHTML(item.name)}" onerror="this.nextElementSibling.style.display='block';this.parentElement.classList.add('no-image');this.remove()"/><span class="product-emoji" style="display:none">${item.icon}</span>`:`<span class="product-emoji">${item.icon}</span>`;
const renderCategories=()=>{categoryList.innerHTML=categories.map(c=>`<button class="category-pill${activeFilter===c.name?' selected':''}" type="button" data-cat="${escapeHTML(c.name)}" aria-label="Show ${escapeHTML(c.label)}"><span class="category-visual">${c.icon}</span><span>${escapeHTML(c.label)}</span></button>`).join('')};
function getFiltered(){const q=productSearch.value.trim().toLocaleLowerCase();return products.filter(p=>(activeFilter==='All'||(activeFilter==='Favorites'?favorites.has(p.id):p.category===activeFilter))&&(!q||`${p.name} ${p.category} ${p.desc}`.toLocaleLowerCase().includes(q)))}
function renderProducts(){const filtered=getFiltered();const canLimit=activeFilter==='All'&&!productSearch.value.trim();const pageSize=window.matchMedia('(max-width:650px)').matches?6:8;const visible=(canLimit&&!expanded)?filtered.slice(0,pageSize):filtered;
  grid.innerHTML=visible.map(p=>`<article class="product-card" data-id="${p.id}"><div class="product-photo${p.img?'':' no-image'}" role="button" tabindex="0" data-detail="${p.id}" aria-label="Details about ${escapeHTML(p.name)}">${imageMarkup(p)}<button type="button" class="save-btn ${favorites.has(p.id)?'saved':''}" data-save="${p.id}" aria-label="${favorites.has(p.id)?'Remove':'Save'} ${escapeHTML(p.name)}" aria-pressed="${favorites.has(p.id)}"><svg><use href="#i-heart" /></svg></button></div><div class="product-body"><div class="product-tag">${escapeHTML(p.category)}</div><h3 class="product-title">${escapeHTML(p.name)}</h3><p class="product-desc">${escapeHTML(p.desc)}</p><div class="product-bottom"><span class="product-note">Quote on request</span><button class="product-plus" type="button" data-quote="${p.id}" aria-label="Request quote for ${escapeHTML(p.name)}">+</button></div></div></article>`).join('');
  $('#emptyState').hidden=filtered.length>0;showMore.hidden=!(canLimit&&filtered.length>pageSize);showMore.innerHTML=expanded?'Show fewer products <svg><use href="#i-arrow" /></svg>':'View more products <svg><use href="#i-arrow" /></svg>';$$('.filter').forEach(b=>{const on=b.dataset.filter===activeFilter;b.classList.toggle('active',on);b.setAttribute('aria-pressed',String(on))});renderCategories();
}
function setFilter(category){activeFilter=category;expanded=true;renderProducts()}
categoryList.addEventListener('click',e=>{const btn=e.target.closest('[data-cat]');if(!btn)return;setFilter(btn.dataset.cat);$('#products').scrollIntoView({behavior:'smooth'})});
$$('.filter').forEach(btn=>btn.addEventListener('click',()=>setFilter(btn.dataset.filter)));
productSearch.addEventListener('input',()=>{clearSearch.hidden=!productSearch.value;expanded=true;renderProducts();});
clearSearch.addEventListener('click',()=>{productSearch.value='';clearSearch.hidden=true;productSearch.focus();renderProducts()});
showMore.addEventListener('click',()=>{expanded=!expanded;renderProducts();if(!expanded)$('#products').scrollIntoView({behavior:'smooth'})});
$('#resetFilters').addEventListener('click',()=>{productSearch.value='';clearSearch.hidden=true;activeFilter='All';expanded=false;renderProducts()});
for(const a of $$('[data-go-category]'))a.addEventListener('click',()=>setFilter(a.dataset.goCategory));
function saveItem(id){favorites.has(id)?favorites.delete(id):favorites.add(id);try{localStorage.setItem('navyugFavorites',JSON.stringify([...favorites]))}catch(_){/* fallback in memory */}renderProducts()}
function openProduct(id){const p=products.find(x=>x.id===id);if(!p)return;const modal=$('#productModal');$('#modalCategory').textContent=p.category.toUpperCase();$('#modalTitle').textContent=p.name;$('#modalDesc').textContent=p.info;$('#modalImage').innerHTML=p.img?`<span class="modal-fallback">${p.icon}</span><img src="${p.img}" alt="${escapeHTML(p.name)}" onerror="this.remove()"/>`:`<span class="modal-fallback">${p.icon}</span>`;$('#modalQuote').dataset.id=id;modal.hidden=false;document.body.classList.add('modal-open');$('#modalClose').focus();}
function closeProduct(){const modal=$('#productModal');modal.hidden=true;document.body.classList.remove('modal-open')}
function preselectQuote(id){const p=products.find(x=>x.id===id);if(!p)return;$('#quoteProduct').value=p.name;closeProduct();$('#enquiry').scrollIntoView({behavior:'smooth'});setTimeout(()=>{$('#quoteForm [name="name"]').focus({preventScroll:true})},420)}
grid.addEventListener('click',e=>{const save=e.target.closest('[data-save]');if(save){e.stopPropagation();saveItem(save.dataset.save);return}const quote=e.target.closest('[data-quote]');if(quote){preselectQuote(quote.dataset.quote);return}const detail=e.target.closest('[data-detail]');if(detail)openProduct(detail.dataset.detail)});
grid.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-detail]')){e.preventDefault();openProduct(e.target.dataset.detail)}});
$('#modalClose').addEventListener('click',closeProduct);
$('#productModal').addEventListener('click',e=>{if(e.target.id==='productModal')closeProduct()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#productModal').hidden)closeProduct()});
$('#modalQuote').addEventListener('click',e=>preselectQuote(e.currentTarget.dataset.id));
const productSelector=$('#quoteProduct');productSelector.innerHTML='<option value="">Select a product</option>'+products.map(p=>`<option value="${escapeHTML(p.name)}">${escapeHTML(p.name)}</option>`).join('')+'<option value="Other / Multiple Products">Other / Multiple Products</option>';
$('#quoteForm').addEventListener('submit',e=>{e.preventDefault();const f=new FormData(e.currentTarget);const val=k=>String(f.get(k)||'').trim();const message=[`Hello Navyug Exim, I'd like to request a quotation.`,``,`Name: ${val('name')}`,val('company')?`Company: ${val('company')}`:'',`Email: ${val('email')}`,`Destination: ${val('country')}`,`Product: ${val('product')}`,val('quantity')?`Quantity: ${val('quantity')}`:'',val('message')?`Requirements: ${val('message')}`:'',``,`Please share availability and an export quotation.`].filter(Boolean).join('\n');const url=`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;const win=window.open(url,'_blank','noopener,noreferrer');if(!win)window.location.assign(url)});
const menuBtn=$('#menuBtn'),mobileMenu=$('#mobileMenu');menuBtn.addEventListener('click',()=>{const open=!mobileMenu.classList.contains('open');mobileMenu.classList.toggle('open',open);menuBtn.setAttribute('aria-expanded',String(open));menuBtn.innerHTML=`<svg><use href="#i-${open?'close':'menu'}" /></svg>`});$$('a',mobileMenu).forEach(a=>a.addEventListener('click',()=>{mobileMenu.classList.remove('open');menuBtn.setAttribute('aria-expanded','false');menuBtn.innerHTML='<svg><use href="#i-menu" /></svg>'}));
const quickLinks=$$('.bottom-nav a');quickLinks.forEach(a=>a.addEventListener('click',()=>{quickLinks.forEach(x=>x.classList.remove('active'));a.classList.add('active')}));
const knownSections=['home','products','enquiry','contact'];if('IntersectionObserver'in window){const ob=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting&&entry.intersectionRatio>.2){quickLinks.forEach(a=>a.classList.toggle('active',a.dataset.nav===entry.target.id))}})},{rootMargin:'-35% 0px -45% 0px'});knownSections.forEach(id=>{const el=$(`#${id}`);if(el)ob.observe(el)})}
$('#year').textContent=new Date().getFullYear();
renderProducts();

