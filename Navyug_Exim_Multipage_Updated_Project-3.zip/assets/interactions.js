/** NAVYUG EXIM — additions for multi-page navigation, social settings, language, gallery and forms. */
(() => {
  'use strict';
  const $ = (q,root=document)=>root.querySelector(q);
  const $$ = (q,root=document)=>Array.from(root.querySelectorAll(q));
  const esc = t=>String(t??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const items = typeof products==='undefined'?[]:products;
  const groups = typeof categories==='undefined'?[]:categories;
  const isHome = document.body.dataset.page==='/' ;
  const wa = '918799548724';

  // The original ZIP's logo, palette, product design and homepage scripts are retained.
  // Other pages share the same product data and styling.
  if (!isHome) {
    const trigger=$('#menuBtn'), menu=$('#mobileMenu');
    trigger?.addEventListener('click',()=>{const open=!menu.classList.contains('open');menu.classList.toggle('open',open);trigger.setAttribute('aria-expanded',String(open));});
    $$('#mobileMenu a').forEach(a=>a.addEventListener('click',()=>{menu?.classList.remove('open');trigger?.setAttribute('aria-expanded','false');}));
  }

  // Link configs live in one file; do not display placeholder profiles as active links.
  const socials=window.NAVYUG_SITE_CONFIG?.socialLinks||{};
  const socialNames={youtube:'YouTube',facebook:'Facebook',instagram:'Instagram',linkedin:'LinkedIn'};
  const socialIcons={
    youtube:'<path d="M21.5 7.3a2.8 2.8 0 0 0-2-2C17.8 4.8 12 4.8 12 4.8s-5.8 0-7.5.5a2.8 2.8 0 0 0-2 2A31 31 0 0 0 2 12a31 31 0 0 0 .5 4.7 2.8 2.8 0 0 0 2 2c1.7.5 7.5.5 7.5.5s5.8 0 7.5-.5a2.8 2.8 0 0 0 2-2A31 31 0 0 0 22 12a31 31 0 0 0-.5-4.7ZM10 15.6V8.4l6 3.6Z"/>',
    facebook:'<path d="M15.2 2H12c-2.5 0-4 1.5-4 4v3H5v4h3v9h4v-9h3.1l.6-4H12V6.5c0-.6.3-1 1-1h2.2Z"/>',
    instagram:'<path d="M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5Zm0 2.4A2.6 2.6 0 0 0 4.4 7v10A2.6 2.6 0 0 0 7 19.6h10a2.6 2.6 0 0 0 2.6-2.6V7A2.6 2.6 0 0 0 17 4.4Zm5 3a4.6 4.6 0 1 1 0 9.2 4.6 4.6 0 0 1 0-9.2Zm0 2.4a2.2 2.2 0 1 0 0 4.4 2.2 2.2 0 0 0 0-4.4Zm5.3-3.7a1.2 1.2 0 1 1 0 2.4 1.2 1.2 0 0 1 0-2.4Z"/>',
    linkedin:'<path d="M4 3a2 2 0 1 1 0 4 2 2 0 0 1 0-4ZM2 9h4v13H2Zm7 0h4v1.7c.8-1.2 2-2 4.2-2 3.5 0 4.8 2 4.8 5.8V22h-4v-6.5c0-2-.6-3-2.1-3-1.8 0-2.9 1.3-2.9 3.1V22H9Z"/>'
  };
  $$('#socialList').forEach(box=>{
    Object.entries(socialNames).forEach(([key,label])=>{
      const url=String(socials[key]||'').trim();
      if(!/^https:\/\/[^\s]+$/i.test(url))return;
      const a=document.createElement('a');a.className='social-link';a.href=url;a.target='_blank';a.rel='noopener noreferrer';a.setAttribute('aria-label',`NAVYUG EXIM on ${label}`);a.title=label;
      a.innerHTML=`<svg viewBox="0 0 24 24" aria-hidden="true">${socialIcons[key]}</svg>`;box.append(a);
    });
  });

  // Searchable, accessible language chooser: redirects to Google's REAL external
  // webpage translation service. It is not a label-only fake or embedded API.
  // The deprecated Google Translate embedded site widget is deliberately avoided.
  const languages=[
    ['en','English','English'],['hi','Hindi','हिन्दी'],['gu','Gujarati','ગુજરાતી'],['ar','Arabic','العربية'],
    ['fr','French','Français'],['de','German','Deutsch'],['es','Spanish','Español'],['zh-CN','Chinese (Simplified)','简体中文'],
    ['zh-TW','Chinese (Traditional)','繁體中文'],['ja','Japanese','日本語'],['ko','Korean','한국어'],['pt','Portuguese','Português'],
    ['ru','Russian','Русский'],['it','Italian','Italiano'],['tr','Turkish','Türkçe'],['bn','Bengali','বাংলা'],
    ['ur','Urdu','اردو'],['pa','Punjabi','ਪੰਜਾਬੀ'],['ta','Tamil','தமிழ்'],['te','Telugu','తెలుగు'],
    ['ml','Malayalam','മലയാളം'],['mr','Marathi','मराठी'],['kn','Kannada','ಕನ್ನಡ'],['th','Thai','ไทย'],
    ['vi','Vietnamese','Tiếng Việt'],['id','Indonesian','Bahasa Indonesia'],['ms','Malay','Bahasa Melayu'],
    ['nl','Dutch','Nederlands'],['pl','Polish','Polski'],['sv','Swedish','Svenska'],['sw','Swahili','Kiswahili'],
    ['fa','Persian','فارسی'],['he','Hebrew','עברית'],['el','Greek','Ελληνικά'],['uk','Ukrainian','Українська'],
    ['ro','Romanian','Română'],['cs','Czech','Čeština'],['da','Danish','Dansk'],['no','Norwegian','Norsk']
  ];
  const langToggle=$('#languageToggle'),langPanel=$('#languagePanel'),langInput=$('#languageSearch'),langList=$('#languageList'),langCurrent=$('#currentLanguage');
  let pref='en';try{pref=localStorage.getItem('navyugLanguage')||'en'}catch(_){}
  function drawLanguages(q=''){
    const query=q.trim().toLocaleLowerCase();langList.innerHTML='';
    const available=languages.filter(x=>x[1].toLowerCase().includes(query)||x[2].toLocaleLowerCase().includes(query)||x[0].toLowerCase().includes(query));
    available.forEach(([code,label,native])=>{
      const b=document.createElement('button');b.type='button';b.className='language-option';b.setAttribute('role','option');b.setAttribute('aria-selected',String(code===pref));b.innerHTML=`<span>${esc(label)}</span><span class="native">${esc(native)}</span>`;
      b.addEventListener('click',()=>{
        pref=code;try{localStorage.setItem('navyugLanguage',pref)}catch(_){}
        langCurrent.textContent=label;langPanel.hidden=true;langToggle.setAttribute('aria-expanded','false');
        if(code==='en'){window.location.assign(window.location.pathname+window.location.search+window.location.hash);return;}
        const currentURL=new URL(window.location.href);
        const googleURL='https://translate.google.com/translate?sl=en&tl='+encodeURIComponent(code)+'&u='+encodeURIComponent(currentURL.href);
        window.location.assign(googleURL);
      });langList.appendChild(b);
    });
    if(!available.length){const p=document.createElement('p');p.textContent='Language not found. Try another spelling.';p.className='translation-note';langList.appendChild(p);}
  }
  if(langToggle){
    langCurrent.textContent=languages.find(x=>x[0]===pref)?.[1]||'English';drawLanguages();
    langToggle.addEventListener('click',()=>{const open=langPanel.hidden;langPanel.hidden=!open;langToggle.setAttribute('aria-expanded',String(open));if(open){langInput.value='';drawLanguages();langInput.focus()}});
    langInput.addEventListener('input',()=>drawLanguages(langInput.value));
    langInput.addEventListener('keydown',e=>{if(e.key==='ArrowDown'){e.preventDefault();$('.language-option',langList)?.focus()}});
    langList.addEventListener('keydown',e=>{if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();const list=$$('.language-option',langList);const idx=list.indexOf(document.activeElement);list[Math.max(0,Math.min(list.length-1,idx+(e.key==='ArrowDown'?1:-1)))]?.focus()}});
    document.addEventListener('click',e=>{if(!$('#languagePicker')?.contains(e.target)){langPanel.hidden=true;langToggle.setAttribute('aria-expanded','false')}});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!langPanel.hidden){langPanel.hidden=true;langToggle.setAttribute('aria-expanded','false');langToggle.focus()}});
  }

  // Shared data-driven cards for separate Products and Categories pages.
  if (!isHome && $('#productsGrid')) {
    const grid=$('#productsGrid'),categoryList=$('#categoryList'),search=$('#productSearch'),clear=$('#searchClear'),more=$('#showMore');
    let filter=new URLSearchParams(window.location.search).get('category')||'All';
    if(filter!=='All'&&!groups.some(g=>g.name===filter))filter='All';
    let favs=new Set();try{favs=new Set(JSON.parse(localStorage.getItem('navyugFavorites')||'[]'))}catch(_){}
    const photo=p=>p.img?`<img src="${esc(p.img)}" alt="Illustrative photo of ${esc(p.name)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.hidden=false"><span class="product-emoji" hidden>${p.icon}</span>`:`<span class="product-emoji">${p.icon}</span>`;
    function render(){
      const query=String(search?.value||'').trim().toLocaleLowerCase();
      const list=items.filter(p=>(filter==='All'||(filter==='Favorites'?favs.has(p.id):p.category===filter))&&(`${p.name} ${p.category} ${p.desc}`.toLowerCase().includes(query)));
      grid.innerHTML=list.map(p=>`<article class="product-card" data-id="${esc(p.id)}"><div class="product-photo${p.img?'':' no-image'}" role="button" tabindex="0" data-detail="${esc(p.id)}" aria-label="Open details about ${esc(p.name)}">${photo(p)}<button type="button" class="save-btn ${favs.has(p.id)?'saved':''}" data-save="${esc(p.id)}" aria-label="${favs.has(p.id)?'Remove saved':'Save'} ${esc(p.name)}" aria-pressed="${favs.has(p.id)}"><svg><use href="#i-heart"></use></svg></button></div><div class="product-body"><div class="product-tag">${esc(p.category)}</div><h3 class="product-title"><a href="/products/${encodeURIComponent(p.id)}/">${esc(p.name)}</a></h3><p class="product-desc">${esc(p.desc)}</p><div class="product-bottom"><span class="product-note">Quote on request</span><a class="product-plus" href="/contact/?product=${encodeURIComponent(p.id)}#enquiry" aria-label="Request quote for ${esc(p.name)}">+</a></div></div></article>`).join('');
      if($('#emptyState'))$('#emptyState').hidden=!!list.length;
      if(more)more.hidden=true;
      $$('.filter').forEach(b=>{const match=b.dataset.filter===filter;b.classList.toggle('active',match);b.setAttribute('aria-pressed',String(match))});
      if(categoryList)categoryList.innerHTML=groups.map(c=>`<button class="category-pill ${filter===c.name?'selected':''}" type="button" data-cat="${esc(c.name)}"><span class="category-visual">${c.icon}</span><span>${esc(c.label)}</span></button>`).join('');
    }
    render();
    categoryList?.addEventListener('click',e=>{const b=e.target.closest('[data-cat]');if(!b)return;filter=b.dataset.cat;render();$('#products')?.scrollIntoView({behavior:'smooth'})});
    $$('.filter').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.filter;render()}));
    search?.addEventListener('input',()=>{if(clear)clear.hidden=!search.value;render()});
    clear?.addEventListener('click',()=>{search.value='';clear.hidden=true;render();search.focus()});
    $('#resetFilters')?.addEventListener('click',()=>{filter='All';if(search)search.value='';render()});
    grid.addEventListener('click',e=>{const btn=e.target.closest('[data-save]');if(btn){const id=btn.dataset.save;favs.has(id)?favs.delete(id):favs.add(id);try{localStorage.setItem('navyugFavorites',JSON.stringify([...favs]))}catch(_){}render();return;}const detail=e.target.closest('[data-detail]');if(detail)window.location.assign(`/products/${encodeURIComponent(detail.dataset.detail)}/`)});
    grid.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-detail]')){e.preventDefault();window.location.assign(`/products/${encodeURIComponent(e.target.dataset.detail)}/`)}});

  }

  // Product photo gallery uses the same original data, with search, filters and an accessible modal.
  const galleryGrid=$('#galleryGrid'),galleryFilters=$('#galleryFilters'),gallerySearch=$('#gallerySearch');
  if(galleryGrid){
    let filter='All';
    function drawGallery(){
      const q=String(gallerySearch.value||'').trim().toLowerCase();
      const list=items.filter(p=>(filter==='All'||p.category===filter)&&`${p.name} ${p.category} ${p.desc}`.toLowerCase().includes(q));
      galleryFilters.innerHTML=[['All','All products','🌿'],...groups.map(c=>[c.name,c.label,c.icon])].map(([id,label,icon])=>`<button type="button" class="filter ${filter===id?'active':''}" data-filter="${esc(id)}" aria-pressed="${filter===id}">${icon} ${esc(label)}</button>`).join('');
      galleryGrid.innerHTML=list.map(p=>`<article class="gallery-tile"><button type="button" class="gallery-photo ${p.img?'':'fallback-photo'}" data-photo="${esc(p.id)}" aria-label="Enlarge photo of ${esc(p.name)}">${p.img?`<img loading="lazy" src="${esc(p.img)}" alt="Illustrative photo: ${esc(p.name)}" onerror="this.style.display='none';this.nextElementSibling.hidden=false"><span class="photo-emoji" hidden>${p.icon}</span>`:`<span class="photo-emoji">${p.icon}</span>`}</button><div class="gallery-tile-copy"><span class="overline">${esc(p.category)}</span><h3>${esc(p.name)}</h3><p>${esc(p.desc)}</p><a href="/products/${encodeURIComponent(p.id)}/">Product details →</a></div></article>`).join('');
      $('#galleryEmpty').hidden=!!list.length;
    }
    drawGallery();
    galleryFilters.addEventListener('click',e=>{const b=e.target.closest('[data-filter]');if(!b)return;filter=b.dataset.filter;drawGallery()});
    gallerySearch.addEventListener('input',()=>{$('#galleryClear').hidden=!gallerySearch.value;drawGallery()});
    $('#galleryClear')?.addEventListener('click',()=>{gallerySearch.value='';$('#galleryClear').hidden=true;drawGallery();gallerySearch.focus()});
    let modal;
    galleryGrid.addEventListener('click',e=>{
      const b=e.target.closest('[data-photo]');if(!b)return;const p=items.find(i=>i.id===b.dataset.photo);if(!p)return;
      if(!modal){modal=document.createElement('div');modal.className='gallery-lightbox';modal.hidden=true;modal.innerHTML='<div class="lightbox-dialog" role="dialog" aria-modal="true" aria-label="Product photo preview"><button class="lightbox-close" aria-label="Close photo preview">✕</button><div class="lightbox-content"></div></div>';document.body.append(modal)}
      $('.lightbox-content',modal).innerHTML=p.img?`<img src="${esc(p.img)}" alt="Illustrative product photograph of ${esc(p.name)}"><p>${esc(p.name)} — illustrative stock photo, not verified as a company product image.</p>`:`<div class="fallback-photo" style="min-height:220px"><span class="photo-emoji">${p.icon}</span><p>${esc(p.name)} — original photograph not supplied.</p></div>`;
      modal.hidden=false;document.body.style.overflow='hidden';$('.lightbox-close',modal).focus();
    });
    document.addEventListener('click',e=>{if(modal&&(e.target===modal||e.target.closest('.lightbox-close'))){modal.hidden=true;document.body.style.overflow=''}});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal&&!modal.hidden){modal.hidden=true;document.body.style.overflow=''}});
  }

  // Original WhatsApp quote form is retained on Home; initialize only on Contact.
  if(!isHome){
    const form=$('#quoteForm'), select=$('#quoteProduct');
    if(form&&select){
      select.innerHTML='<option value="">Select a product</option>'+items.map(p=>`<option value="${esc(p.name)}" data-id="${esc(p.id)}">${esc(p.name)}</option>`).join('');
      const wanted=new URLSearchParams(window.location.search).get('product');
      const item=items.find(p=>p.id===wanted);if(item)select.value=item.name;
      form.addEventListener('submit',event=>{
        event.preventDefault();if(!form.reportValidity())return;
        const d=new FormData(form),val=k=>String(d.get(k)||'').trim();
        const message=[`Hello NAVYUG EXIM, I would like to request an export quotation.`, `Name: ${val('name')}`,val('company')?`Company: ${val('company')}`:'',`Email: ${val('email')}`,`Destination: ${val('country')}`,`Product: ${val('product')}`,val('quantity')?`Quantity: ${val('quantity')}`:'',val('message')?`Requirements: ${val('message')}`:'', 'Please share availability and an export quotation.'].filter(Boolean).join('\n');
        const url=`https://wa.me/${wa}?text=${encodeURIComponent(message)}`;
        const popup=window.open(url,'_blank','noopener,noreferrer');if(!popup)window.location.assign(url);
      });
    }
  }
})();
