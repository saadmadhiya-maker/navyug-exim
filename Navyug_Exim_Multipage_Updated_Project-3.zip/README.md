# NAVYUG EXIM — Batch 1 Final Update (October 13, 2026)

This project **modifies the previous vanilla HTML/CSS/JavaScript NAVYUG EXIM website**; original design styles remain in `assets/original.css`, with targeted overrides in `assets/revision.css`. It is still a static, mobile-friendly website with 16 shared catalog products and no npm build dependencies.

## Changes applied

1. Search focus: orange/gold box outline removed. Subtle green focus indication remains.
2. Enquiry form focus: same change.
3. Compact flag + language-code selector, English/native name search, scrollable keyboard navigation. Language choices call the actual Cloudflare translation API route, not a fake selector.
4. Consistent round WhatsApp icon on desktop/mobile/all routes.
5. English NAVYUG EXIM brand protected with `translate="no"`/`notranslate` elements; API does not translate these text nodes.
6. External Google Translate error/dog redirect removed. **Translation requires a Google Cloud Translation API key stored as a Cloudflare secret**. Without the key, an inline message explains that translation is not configured, and English content remains unchanged.
7. Fixed-size layouts, stable scrollbar, CSS cross-document View Transitions where supported, reduced-motion support. No claim of zero network-induced delay.
8. `/categories/` and `/gallery/` pages removed and redirected to `/products/`. New `/blog/` page. Home's original product popup retained; Products grid now opens the same popup. Individual product detail URLs remain for sharing/search.
9. Four official social media destinations added to footer via centralized config.
10. Footer includes `Created by Saad Madhiya` with clickable name linking to the user-supplied LinkedIn profile.
11. Four supplied photos resized and embedded locally for Makhana, Wheat Flour, Salt and Confectionery, with image updates on cards, popups and details.

## Cloudflare Pages: keep existing GitHub+ZIP workflow

Your last screenshot showed:
- Repository: `saadmadhiya-maker/navyug-exim`, branch: `main`
- Framework: `None`
- **Build command:** `python3 -m zipfile -e Navyug_Exim_Multipage_Updated_Project-3.zip dist`
- **Build output directory:** `dist`
- Root directory: blank

The final ZIP was deliberately named **exactly** `Navyug_Exim_Multipage_Updated_Project-3.zip` so that you can replace the existing ZIP in the GitHub repository **without changing Cloudflare's build command**.

1. Save this ZIP under that exact name (remove/rename any duplicate older downloads as needed).
2. Open your GitHub repo on the `main` branch.
3. Select **Add file → Upload files**, and choose only this updated ZIP with the EXACT name. The previously committed ZIP at the same path will be replaced when you commit.
4. Leave the old `index.html` file alone; the build extracts the ZIP's newer `index.html` into `dist`.
5. Commit directly to `main`.
6. Open Cloudflare Pages → `navyug-exim` → Deployments. Confirm that the newest commit succeeded (do not assume success). Check `/`, `/products/`, `/blog/`, `/contact/`, and an individual product URL.

**Do not upload an extracted HTML file in place of the ZIP; Cloudflare is configured to extract the ZIP.**

### Why `_worker.js`?

Cloudflare Pages [advanced-mode Pages Functions](https://developers.cloudflare.com/pages/functions/advanced-mode/) supports a `_worker.js` file inside the output folder (`dist`). It forwards all non-API requests to `env.ASSETS.fetch(request)`, preserving static routes, and provides `/api/translate`. No database or additional package is needed.

## Enable real worldwide translation (required)

1. In Google Cloud Console, create/select a project with billing enabled; enable **Cloud Translation API (Basic v2)**.
2. Create an API key with the minimum possible API restrictions (Cloud Translation API). Configure a Google Cloud Translation quota and billing budget alerts to reduce billing exposure. A publicly callable translation proxy may incur charges, so consider setting Cloudflare WAF/rate limits on `/api/translate` before production use.
3. In Cloudflare → Workers & Pages → `navyug-exim` → Settings → Variables and secrets, add a **secret** (not plaintext frontend variable) named `GOOGLE_TRANSLATE_API_KEY` with that key value. Apply it to Production (and Preview only if needed).
4. Trigger a new deployment so that the secret binding is available. Then test a language from `/products/` and repeat on `/blog/` and `/contact/`.
5. The language is remembered in visitor's browser localStorage. Search supports English and native language names.

**Without step 1–4, translation is intentionally *not* presented as working**. Choosing another language produces a clear local configuration notice, not an external error page. Some difficult languages/RTL layouts and highly dynamic content still need manual review with the live key. The header/brand/logo proper noun is protected; owner/company addresses and phone numbers are excluded from text translation.

## Configurable social links

Edit exactly these four values in `src/config/siteConfig.js`:

```
window.NAVYUG_SITE_CONFIG.socialLinks.youtube
window.NAVYUG_SITE_CONFIG.socialLinks.facebook
window.NAVYUG_SITE_CONFIG.socialLinks.instagram
window.NAVYUG_SITE_CONFIG.socialLinks.linkedin
```

Official links supplied in this request are already entered. `creatorLink` is the supplied Saad Madhiya LinkedIn URL.

## Files changed

- `assets/revision.css` — style overrides, seamless UI, focus visuals, language flags, blog cards, WhatsApp.
- `assets/revision.js` — products page modal functionality / keyboard handling.
- `assets/translation.js` — searchable selector, API communication, text translation + per-page persistence.
- `assets/interactions.js` — removed legacy external translation redirect and changed product click behavior.
- `assets/catalog.js` — four updated local image paths.
- `assets/products/*.webp` — newly provided product photographs.
- `_worker.js` — optional real Cloud Translation API proxy (requires secure secret).
- `_redirects` — old removed URLs to `/products/`.
- `blog/index.html` — new blog.
- Every existing HTML page — updated header/footer, stylesheet/script references, English brand protection, WhatsApp button.
- `src/config/siteConfig.js` — four official social URLs and creator URL.
- `sitemap.xml`, `tests/static_audit.py` — new site structure/tests.

## Limitations

- Original owner photographs and actual certificates have not been newly provided/verified, so existing documented placeholders remain. No certifications were invented.
- Browser tests in the execution environment were blocked by admin restrictions. Static tests and local code/mock Worker tests succeeded, but mobile/desktop visual review, actual form handoff, dynamic translation and live Cloudflare deployment remain manual checks.
- The existing catalog still includes external illustrative product images for products other than the four updated local images. Verify product authenticity before client publication.
