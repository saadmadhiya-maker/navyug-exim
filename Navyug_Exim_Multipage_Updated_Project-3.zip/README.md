# NAVYUG EXIM — multi-page upgrade of original ZIP

## Original framework
The uploaded ZIP contained **one index.html** with inline CSS and vanilla JavaScript (no npm, React, build tool or dependencies). The existing CSS and homepage structure were preserved and extracted to `assets/original.css` and `assets/home-original.js` so other pages reuse the same design. The original file was backed up separately as `Navyug_Exim_Original_Backup.zip`.

## Build / Cloudflare Pages
This is a static, ready-to-deploy HTML site. No npm installation is needed.

- Framework preset: **None**
- Production branch: **main**
- Build command: **exit 0** (or blank if Cloudflare accepts no build command)
- Build output directory: **.** (dot)
- Root directory: **/**

Each route is a real HTML document under its own folder: `/about/index.html`, `/products/index.html`, etc. Cloudflare Pages serves directory index pages on direct URL requests and browser refresh. No SPA catch-all rewrite is required or desired.

## Key files
- `index.html`: original homepage structure & appearance maintained
- `assets/original.css`: extracted original styling without redesign
- `assets/additions.css`: new page/layout/header/language/gallery styling
- `assets/catalog.js`: original 16 products and categories, shared by every page
- `assets/home-original.js`: original homepage behavior
- `assets/interactions.js`: multi-page product filtering, gallery, lightbox, translation UI, navigation, forms
- `src/config/siteConfig.js`: four **empty** social media URLs, update there
- `about/`, `products/`, `categories/`, `gallery/`, `certificates/`, `contact/`: actual pages
- `sitemap.xml`, `robots.txt`: SEO

## Social links (exact four values)
Edit `src/config/siteConfig.js`:

```js
youtube: '',   // Replace with actual official YouTube URL
facebook: '',  // Replace with actual official Facebook URL
instagram: '', // Replace with actual official Instagram URL
linkedin: ''   // Replace with actual official LinkedIn URL
```

Only valid `https://` values are rendered as links. Empty values are hidden.

## Translation
The language chooser is a keyboard-operable searchable menu with 35+ languages. Clicking a language opens an actual external Google Translate website-translation URL with the **current page URL** and requested target language. This is *not* an embedded / API-based real-time translation engine and does not alter the local site DOM. It is dependent on Google Translate's support by region and may not preserve navigation correctly. The legacy Google Website Translator widget became unsupported Oct 2026. For guaranteed in-site automated sitewide translations, deploy a supported translation service or a **server-side Cloud Translation API** integration (requires API credentials/billing and server-side proxy; never put keys in public JS). Browser built-in Translate is another reliable fallback. No keys are shipped.

## Missing verified materials
The referenced developer website could not be fetched in this environment. The ZIP contains **no** authentic owner/director portraits, certificate scans, identifiable certificate details or verified company historical claims. Provide original JPG/PNG portraits and their exact names/designations, certificate PDF/image originals with titles and validity if relevant, company history text, and original product imagery (current product photos are third-party illustrative stock links and some emoji fallbacks). The map is pinned to the **user-provided Google Maps coordinates** for Juni Sendhani; this is not claimed to be the precise shop entrance.

## Deployment updates to existing repo
1. Create a local backup of your current GitHub repository (or use GitHub history to restore).
2. Extract this ZIP. On GitHub `saadmadhiya-maker/navyug-exim`, upload the root `index.html`, `assets/`, `about/`, `products/`, `categories/`, `gallery/`, `certificates/`, `contact/`, `src/`, `robots.txt`, `sitemap.xml` and `README.md`. Keep all subfolder paths exactly.
3. Commit the changes on `main`. Because Cloudflare Pages Git integration is active, it should build automatically.
4. Cloudflare Pages settings: Framework None / Build `exit 0` / Output `.`. Confirm the deployed site opens `https://navyug-exim.pages.dev/` and directly open `https://navyug-exim.pages.dev/about/` in a new browser tab.
5. If browser still shows old version, inspect Cloudflare Pages `Deployments` to ensure `main` deployment succeeded, then hard refresh. No credential required in static code.

## Media notice
Some original URL-based product/hero images are hosted on `images.unsplash.com` and require network access. The site includes emoji fallbacks. Replace with approved real product/company photos when provided.
