# NAVYUG EXIM Round 4 — source-level repair

* FAQ: replaces fragile brand `<span>` with `<strong class="notranslate">` inside `.faq-question` and uses dedicated plus indicator. Eliminates rotated/overlaid company name; prevents translation of brand.
* Language: removes unsupported flag emoji (GB glyph), keeps multicolour translator picture and compact EN code.
* Product popup: full-size images use `contain` and phone modal scrolls.
* Mobile category cards: 3-column grid instead of horizontal clipped strip.
* Search and quote inputs: no orange focus border.
* CSS/JS references: cache-busting `?v=nx-r4-20261013b` on all pages. New `assets/round4.css` override.
* Verify deployment: `/release.txt` must show `NX-R4-20261013b`.
* Translation requires a Google Cloud Translation API secret on Cloudflare (`GOOGLE_TRANSLATE_API_KEY`) for complete languages. Partial offline Hindi/Gujarati remains.

**The bundled source has been changed, but GitHub and Cloudflare production have not been modified by this ZIP creation.**
