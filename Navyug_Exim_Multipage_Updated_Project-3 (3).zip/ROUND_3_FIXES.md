# Round 3 – Mobile Card and FAQ Repair

1. Corrected the root-cause FAQ broad `summary span` CSS selector, so the company name does not rotate or overlap its question.
2. Made the mobile product popup independently vertically scrollable; never crop the card on narrow/short devices.
3. On mobile, the product image retains `object-fit: contain` and its visual area scales with viewport height.
4. Kept existing desktop layout, branding, footer and language picker changes.
5. Added `/release.txt` so the deployed ZIP version can be checked without relying on browser caching.

The translation API still requires the Cloudflare Pages secret `GOOGLE_TRANSLATE_API_KEY` to translate the complete website in all languages; the bundled offline Hindi/Gujarati dictionary is partial.
