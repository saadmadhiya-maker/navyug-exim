# NAVYUG EXIM — 14 October 2026 catalog + bug-fix update

This ZIP is **an in-place enhancement of the previous vanilla HTML/CSS/JS multi-page website**. The logo image, layout, original.css and original homepage structure are preserved.

## New customer journey

- `/products/`: 10 categories and search; 16 **already listed** products in the existing ZIP.
- `/products/category/<category>/`: 10 separate category URLs and relevant product cards only.
- `/products/<existing-product-id>/`: 16 existing product URLs improved with descriptions and varieties.
- `/products/<existing-product-id>/variety/<variety>/`: 27 variety URLs, enquiry-specific contact forms, size/grade/packing marked as requiring confirmation.
- Examples: `/products/category/vegetables/`, `/products/tomato/`, `/products/red-onion/variety/white-onion/`.

**Inventory accuracy:** the 16 existing products are not re-verified as current company inventory. White/Pink/Baby Onion, Roma/Cherry Tomato, Brown Basmati, long green chili and others are labelled **additional enquiry – availability unconfirmed**; they are NOT represented as currently sold/exported. Their detail pages show an honest illustrated placeholder, not a falsely labeled or recycled photo. High-resolution photos for these unconfirmed varieties still need to be supplied or sourced/licensed. 4 photos from earlier user uploads remain in `assets/products/`; the remaining original catalog uses pre-existing Unsplash URLs, which require external network connectivity.

## Bugs addressed

1. FAQ question rebuilt as a simple text block with a separate dedicated right-hand accordion indicator, avoids rotated company name and overlap.
2. Header language icon changed to lightweight inline translation SVG; no GB text or emoji flags in toggle. Original logo asset `/assets/navyug-logo.png` remains unchanged.
3. Existing modal uses contained imagery with appropriate padding; original Unsplash image URL changed from forced crop to `fit=max`, avoiding image-service crop. Photos already cropped at the source cannot be reconstructed.
4. Updated sitemap and local image fallback/hidden-state rules; keyboard and touch responsive catalog.
5. Added query parameter `variety` to existing Contact form and prefilled requirements for quote.
6. Translation uses same Cloudflare Pages `_worker.js` API proxy, with cache where available and user-friendly fallback. The raw `GOOGLE_TRANSLATE_API_KEY` setup error is no longer exposed to website visitors.

## Translation: important limits

**Full automatic translation of all text for 40 languages is NOT available without the API credential.** The dropdown is real/searchable. Without the API, visitors can choose Hindi and Gujarati for a basic partial on-device interface dictionary, plus common UI labels in French, German, Spanish and Arabic. Remaining English content is explicitly disclosed; unsupported languages remain substantially English. The original NAVYUG EXIM logo/brand images never change. Arabic text is styled RTL without reversing the header/site grid. With a configured key, frontend text-node translation requests to the Worker are used across pages; dynamic content requests are watched. User's language persists in localStorage.

To enable full Cloud Translate v2 Basic:
1. Enable Google Cloud Translation API with billing/quota set.
2. Generate a restricted API key (API restriction: Cloud Translation API).
3. Cloudflare dashboard → Workers & Pages → `navyug-exim` → Settings → Variables and secrets → **Add** → Type **Secret** → Name `GOOGLE_TRANSLATE_API_KEY` → API key as value → Production.
4. Redeploy and verify languages on the Home and Products routes. Set WAF/rate limits for `/api/translate` to reduce abuse/billing exposure.
5. Never place the key in `index.html`, `assets` files, or GitHub.

Translations use server-side Cloudflare caching (24h where available) and browser sessionStorage. Actual paid API calls and cost have **NOT** been live-tested without credentials.

## Deployment: existing GitHub + Cloudflare ZIP workflow

Repository `saadmadhiya-maker/navyug-exim`, branch `main`, Cloudflare Pages `navyug-exim`.

- Existing **Build command**: `python3 -m zipfile -e Navyug_Exim_Multipage_Updated_Project-3.zip dist`
- Framework preset: None
- Build output directory: `dist`
- Root directory: blank

1. Keep the download filename **exactly** `Navyug_Exim_Multipage_Updated_Project-3.zip` (rename if browser adds `(1)` or `(2)`).
2. GitHub repository → Add file → Upload files → upload the ZIP at repository root using the same filename and commit to `main`.
3. Cloudflare should build automatically. Check latest SHA and **Success**, then `https://navyug-exim.pages.dev/release.txt` must report `NX-R5-20261014-CATALOG-TRANSLATION-FAQ`.
4. Then check `/`, `/products/`, `/products/category/vegetables/`, `/products/red-onion/`, `/products/red-onion/variety/white-onion/`, `/contact/` and a quote submission. Do not retry older deployments.

For local viewing, unzip and run `python3 -m http.server 8000` inside folder, open `http://localhost:8000/`. Full Cloudflare Pages Functions run only in Cloudflare/Wrangler environment, not in the Python file server.

## Files changed

- `index.html`: original home preserved; FAQ text markup separated, translation icon changed.
- `products/index.html`: category-first catalog UX and live search.
- `products/category/*/index.html` (10 routes): new actual category pages.
- `products/<id>/index.html` (16 routes): matching varieties/cards with links and quote CTA.
- `products/<id>/variety/*/index.html` (27 routes): new variety detail pages, honest availability and proper breadcrumbs.
- `assets/catalog-journey.css/js`: new catalog visuals and search behavior.
- `assets/fixes-r5.css`: precise focus/FAQ/modal/translation styling.
- `assets/translation.js` and `assets/locales.js`: secure fallback, caching, more essential translations.
- `_worker.js`: sanitized no-key messages and optional 24h translation cache.
- `assets/interactions.js`: variety enquiry prefilled on contact page.
- Shared HTML references: CSS cache busting, header language icon, preserve logo and links.
- `sitemap.xml`, `release.txt`: includes all 59 routes/version identifier.

No framework/build tool or new npm dependency was added.
