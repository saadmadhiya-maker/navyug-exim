/** Cloudflare Pages advanced-mode Worker: preserves static assets and proxies paid Google Cloud Translation API.
 * Add GOOGLE_TRANSLATE_API_KEY as an encrypted Cloudflare Pages environment SECRET.
 * Unconfigured status returns JSON; users never leave the website or see a broken external Google Translate page.
 */
const supported = new Set(['en','hi','gu','ar','fr','de','es','zh-CN','zh-TW','ja','ko','pt','ru','it','tr','bn','ur','pa','ta','te','ml','mr','kn','th','vi','id','ms','nl','pl','sv','sw','fa','he','el','uk','ro','cs','da','no','az']);
const reply=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json;charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});
export default {
  async fetch(request,env){
    const url=new URL(request.url);
    if(url.pathname!=='/api/translate')return env.ASSETS.fetch(request);
    if(request.method!=='POST')return reply({error:'POST required'},405);
    const origin=request.headers.get('origin');
    if(origin&&origin!==url.origin)return reply({error:'Origin not allowed'},403);
    if(!env.GOOGLE_TRANSLATE_API_KEY)return reply({error:'Translation is temporarily unavailable.'},503);
    let payload;
    try{payload=await request.json()}catch(_){return reply({error:'Invalid JSON'},400)}
    const lang=payload?.target,arr=payload?.texts;
    if(!supported.has(lang)||!Array.isArray(arr)||arr.length<1||arr.length>40||arr.some(x=>typeof x!=='string'||x.length>900)||arr.reduce((a,b)=>a+b.length,0)>7000)return reply({error:'Unsupported language or input size'},400);
    if(lang==='en')return reply({translations:arr});
    try{
      const encoded=new TextEncoder().encode(lang+'|'+arr.join('␞'));
      const bytes=await crypto.subtle.digest('SHA-256',encoded);
      const digest=[...new Uint8Array(bytes)].map(x=>x.toString(16).padStart(2,'0')).join('');
      const cache=typeof caches!=='undefined'?caches.default:null;
      const cacheRequest=new Request(url.origin+'/__nx_translation_cache/'+digest);
      if(cache){const hit=await cache.match(cacheRequest);if(hit)return hit}
      const endpoint='https://translation.googleapis.com/language/translate/v2?key='+encodeURIComponent(env.GOOGLE_TRANSLATE_API_KEY);
      const upstream=await fetch(endpoint,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({q:arr,target:lang,source:'en',format:'text'})});
      const data=await upstream.json();
      if(!upstream.ok||!Array.isArray(data?.data?.translations))return reply({error:'Translation provider rejected this request. Check Cloud Translation billing, permissions and quota.'},502);
      const result=reply({translations:data.data.translations.map(x=>String(x.translatedText||''))});
      if(cache){const cacheResponse=new Response(result.body,{status:200,headers:{'content-type':'application/json;charset=utf-8','cache-control':'public, max-age=86400'}});try{await cache.put(cacheRequest,cacheResponse.clone())}catch(_){ }return cacheResponse}
      return result;
    }catch(_){return reply({error:'Translation service is temporarily unavailable. Please try again.'},502)}
  }
};
