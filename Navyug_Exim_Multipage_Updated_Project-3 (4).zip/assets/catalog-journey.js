/** Added hierarchical catalog interaction. Data is in assets/catalog.js. */
(()=>{'use strict';
 const search=document.querySelector('#catalogSearch');if(!search)return;
 const cats=[...document.querySelectorAll('#journeyCategoryGrid>a')],items=[...document.querySelectorAll('#journeyProductGrid>a')],empty=document.querySelector('#catalogEmpty');
 search.addEventListener('input',()=>{const q=search.value.trim().toLocaleLowerCase();let visible=0;
  cats.forEach(c=>{const matches=c.textContent.toLocaleLowerCase().includes(q);c.hidden=!matches;if(matches)visible++});
  items.forEach(c=>{const matches=c.textContent.toLocaleLowerCase().includes(q);c.hidden=!matches;if(matches)visible++});
  if(empty)empty.hidden=visible>0;
 });
})();